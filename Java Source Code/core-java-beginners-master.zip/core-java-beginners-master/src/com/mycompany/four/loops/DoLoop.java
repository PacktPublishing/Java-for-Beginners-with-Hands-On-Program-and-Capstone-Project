package com.mycompany.four.loops;

public class DoLoop {

    public static void main(String[] args) {

        int num = 50;
        do{
            System.out.println(num);
            num = num - 1;
        }while(num > 0);
    }
}
