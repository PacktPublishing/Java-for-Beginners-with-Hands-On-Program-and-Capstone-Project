package com.mycompany.fourteen.interfacepkg;

public interface SuperAnimal {

    int age = 23;//by default becomes public static final
    void speak();// by default becomes public abstract
}
