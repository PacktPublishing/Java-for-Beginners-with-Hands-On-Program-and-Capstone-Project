package com.mycompany.fourteen.interfacepkg;

public class Tiger implements Animal {
    @Override
    public void speak() {
        System.out.println("roar");
    }
}
