package com.mycompany.thirteen.finalpkg;

public class Apple extends Fruit {

//    @Override
//    public void displayName()
//    {
//        System.out.println("Apple Class");
//    }

}
