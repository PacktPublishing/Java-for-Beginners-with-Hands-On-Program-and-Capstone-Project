package com.mycompany.thirteen.finalpkg;

public class FinalDemoMain {

    public static void main()
    {
        final int count = 5;
        //count = 7;// final variable's value cannot be changed, final is used to create constants in java
    }
}
