package com.mycompany.five.controlstatements;

public class TernaryOperator {
    public static void main(String[] args) {
        int num = 5<3 ? 4 : 7;
        System.out.println(num);
    }
}
