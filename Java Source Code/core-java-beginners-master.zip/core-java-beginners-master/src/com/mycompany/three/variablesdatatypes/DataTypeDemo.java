package com.mycompany.three.variablesdatatypes;

public class DataTypeDemo {

    public static void main(String a[]){
        int num1 = 5;
        int num2 = 7;
        int num3 = num2;
        int num4 = num1 + num2;
        num4 *= num2;
        System.out.println(num4);

        float x = 6.7f;
        double y = 68;
        boolean isAllowedDriving = true;
        long empId = 67676L;

        String name = "John Doe";
        char yesOrNo = 'Y';
    }
}
