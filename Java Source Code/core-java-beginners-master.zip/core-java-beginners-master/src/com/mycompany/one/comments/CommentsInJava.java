package com.mycompany.one.comments;

public class CommentsInJava {

    public static void main(String[] args) {
        // write your code here
        // System.out.println("Single line comment");
        /* System.out.println("Multi line comment");
           System.out.println("Hello World");*/
           System.out.println("Example of multiline and single line comment");

    }
}

