package com.mycompany.two.naming;

public class NamingConvention {

    //To name a class and interface follow pascal case, 1st letter of every word should be capital rest small
    // Example : NamingConvention

    //Packages should be in small letters with no spaces or special characters

    // Variables should follow camelCase
    // Example: int bookPriceForUnit; Better readable
    // Example: int bookpriceforunit; Not readable

    // Methods or Functions follow camelCase same as variables
    //int calculateArea();

    // int MAX_AGE = 55;//constants are declared as capital with _ as seperator
    //Keywords in java
    // public , class , int
    // java.lang
    // java.io

    int _abc;
    int abc123;
    int abc12;
}
